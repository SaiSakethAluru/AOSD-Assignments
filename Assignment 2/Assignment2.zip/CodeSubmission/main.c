#include "disk.h"
#include "sfs.h"


int main(){
	return 0;
}